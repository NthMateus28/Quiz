package com.mateus.quizdoprojetofinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.mateus.quizdoprojetofinal.atividade.MainActivity;

import static com.mateus.quizdoprojetofinal.atividade.MainActivity.acertos;

public class QuestaoQuatro extends AppCompatActivity {
    private Button btnSteven, btnGeorge, btnDisney, btnQuentin;
    private TextView txtCashQ4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questao_quatro);

        btnSteven = findViewById(R.id.btnSete);
        btnGeorge = findViewById(R.id.btnOnze);
        btnDisney = findViewById(R.id.btnDez);
        btnQuentin = findViewById(R.id.btnCinco);
        txtCashQ4 = findViewById(R.id.txtCashQ10);

        txtCashQ4.setText(" " + MainActivity.acertos);

        btnSteven.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirProx();
            }
        });
        btnGeorge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                acertos = acertos + 1000;
                abrirProx();
            }
        });
        btnDisney.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirProx();
            }
        });
        btnQuentin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirProx();
            }
        });
    }
    private void abrirProx()
    {
        Intent janela = new Intent(this, QuestaoCinco.class);
        startActivity(janela);
        finish();
    }

    @Override
    public void onBackPressed() {
        Toast.makeText(this, "Você não pode voltar!", Toast.LENGTH_LONG).show();
    }
}