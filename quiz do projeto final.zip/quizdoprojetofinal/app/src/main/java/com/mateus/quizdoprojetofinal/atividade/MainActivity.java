package com.mateus.quizdoprojetofinal.atividade;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

import com.mateus.quizdoprojetofinal.ComoJogar;
import com.mateus.quizdoprojetofinal.QuestaoUm;
import com.mateus.quizdoprojetofinal.R;

public class MainActivity extends AppCompatActivity {
    private Button btnIniciar, btnComo;

    public static int acertos = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnIniciar = findViewById(R.id.btnComecar);
        btnComo = findViewById(R.id.btnComo);

        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);


        btnIniciar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirFaseUm();
            }
        });
        btnComo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirComo();
            }
        });
    }
    public void abrirFaseUm()
    {
        Intent janelau = new Intent(this, QuestaoUm.class);
        startActivity(janelau);
    }
    public void abrirComo()
    {
        Intent janelac = new Intent(this, ComoJogar.class);
        startActivity(janelac);
    }
}