package com.mateus.quizdoprojetofinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.mateus.quizdoprojetofinal.atividade.MainActivity;

import static com.mateus.quizdoprojetofinal.atividade.MainActivity.acertos;

public class QuestaoSeis extends AppCompatActivity {
    private Button btnQuatro, btnDois, btnTres, btnSeis;
    private TextView txtCashQ6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questao_seis);

        btnQuatro = findViewById(R.id.btnSete);
        btnDois = findViewById(R.id.btnOnze);
        btnTres = findViewById(R.id.btnDez);
        btnSeis = findViewById(R.id.btnCinco);
        txtCashQ6 = findViewById(R.id.txtCashQ10);

        txtCashQ6.setText(" " + MainActivity.acertos);

        btnQuatro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirProx();
            }
        });
        btnDois.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirProx();
            }
        });
        btnTres.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                acertos = acertos + 1000;
                abrirProx();
            }
        });
        btnSeis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirProx();
            }
        });
    }
    private void abrirProx()
    {
        Intent janela = new Intent(this, QuestaoSete.class);
        startActivity(janela);
        finish();
    }
}