package com.mateus.quizdoprojetofinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.mateus.quizdoprojetofinal.atividade.MainActivity;

import static com.mateus.quizdoprojetofinal.atividade.MainActivity.acertos;

public class QuestaoSete extends AppCompatActivity {
    private Button btnOrdem, btnKaut, btnImperio, btnFamilia;
    private TextView txtCashQ7;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questao_sete);

        btnOrdem = findViewById(R.id.btnSete);
        btnKaut = findViewById(R.id.btnOnze);
        btnImperio = findViewById(R.id.btnDez);
        btnFamilia = findViewById(R.id.btnCinco);
        txtCashQ7 = findViewById(R.id.txtCashQ10);

        txtCashQ7.setText(" " + MainActivity.acertos);

        btnOrdem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirProx();
            }
        });
        btnKaut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirProx();
            }
        });
        btnImperio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                acertos = acertos + 1000;
                abrirProx();
            }
        });
        btnFamilia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirProx();
            }
        });
    }
    private void abrirProx()
    {
        Intent janela = new Intent(this, QuestaoOito.class);
        startActivity(janela);
        finish();
    }
}