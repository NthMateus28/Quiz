package com.mateus.quizdoprojetofinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

import static com.mateus.quizdoprojetofinal.atividade.MainActivity.acertos;

public class QuestaoUm extends AppCompatActivity {
    private Button btnPadme, btnRey, btnUnduli, btnLeia;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questao_um);

        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        
        btnPadme = findViewById(R.id.btnSete);
        btnRey = findViewById(R.id.btnOnze);
        btnUnduli = findViewById(R.id.btnDez);
        btnLeia = findViewById(R.id.btnCinco);
        
        btnPadme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirProx();
            }
        });
        btnRey.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirProx();
            }
        });
        btnUnduli.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirProx();
            }
        });
        btnLeia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                acertos = acertos + 1000;
                abrirProx();
            }
        });
    }
    public void abrirProx()
    {
        Intent janelap = new Intent(this, QuestaoDois.class);
        startActivity(janelap);
        finish();
    }

    @Override
    public void onBackPressed() {
        Toast.makeText(this, "Você não pode voltar!", Toast.LENGTH_LONG).show();
    }
}