package com.mateus.quizdoprojetofinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.mateus.quizdoprojetofinal.atividade.MainActivity;

import static com.mateus.quizdoprojetofinal.atividade.MainActivity.acertos;

public class QuestaoOito extends AppCompatActivity {
    private Button btnMace, btnQuiAdi, btnQui, btnHan;
    private TextView txtCashQ8;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questao_oito);

        btnMace = findViewById(R.id.btnSete);
        btnQuiAdi = findViewById(R.id.btnOnze);
        btnQui = findViewById(R.id.btnDez);
        btnHan = findViewById(R.id.btnCinco);
        txtCashQ8 = findViewById(R.id.txtCashQ10);

        txtCashQ8.setText(" " + MainActivity.acertos);

        btnMace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirProx();
            }
        });
        btnQuiAdi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirProx();
            }
        });
        btnQui.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                acertos = acertos + 1000;
                abrirProx();
            }
        });
        btnHan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirProx();
            }
        });
    }
    private void abrirProx()
    {
        Intent janela = new Intent(this, QuestaoNove.class);
        startActivity(janela);
        finish();
    }
}