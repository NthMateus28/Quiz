package com.mateus.quizdoprojetofinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.mateus.quizdoprojetofinal.atividade.MainActivity;

import static com.mateus.quizdoprojetofinal.atividade.MainActivity.acertos;

public class QuestaoNove extends AppCompatActivity {
    private Button bbtnPadme, btnLeia, btnLuminara, btnMon;
    private TextView txtCashQ9;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questao_nove);

        bbtnPadme = findViewById(R.id.btnSete);
        btnLeia = findViewById(R.id.btnOnze);
        btnLuminara = findViewById(R.id.btnDez);
        btnMon = findViewById(R.id.btnCinco);
        txtCashQ9 = findViewById(R.id.txtCashQ10);

        txtCashQ9.setText(" " + MainActivity.acertos);

        bbtnPadme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                acertos = acertos + 1000;
                abrirProx();
            }
        });
        btnLeia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirProx();
            }
        });
        btnLuminara.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirProx();
            }
        });
        btnMon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirProx();
            }
        });
    }
    private void abrirProx()
    {
        Intent janela = new Intent(this, QuestaoDez.class);
        startActivity(janela);
        finish();
    }
}