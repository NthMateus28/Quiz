package com.mateus.quizdoprojetofinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.mateus.quizdoprojetofinal.atividade.MainActivity;

import static com.mateus.quizdoprojetofinal.atividade.MainActivity.acertos;

public class QuestaoCinco extends AppCompatActivity {
    private Button btnTattonie, btnNaboo, btnAlderaan, btnDagobah;
    private TextView txtCashQ5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questao_cinco);

        btnTattonie = findViewById(R.id.btnSete);
        btnNaboo = findViewById(R.id.btnOnze);
        btnAlderaan = findViewById(R.id.btnDez);
        btnDagobah = findViewById(R.id.btnCinco);
        txtCashQ5 = findViewById(R.id.txtCashQ10);

        txtCashQ5.setText(" " + MainActivity.acertos);

        btnTattonie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                acertos = acertos + 1000;
                abrirProx();
            }
        });
        btnNaboo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirProx();
            }
        });
        btnAlderaan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirProx();
            }
        });
        btnDagobah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirProx();
            }
        });
    }
    private void abrirProx()
    {
        Intent janela = new Intent(this, QuestaoSeis.class);
        startActivity(janela);
        finish();
    }
    @Override
    public void onBackPressed() {
        Toast.makeText(this, "Você não pode voltar!", Toast.LENGTH_LONG).show();
    }
}