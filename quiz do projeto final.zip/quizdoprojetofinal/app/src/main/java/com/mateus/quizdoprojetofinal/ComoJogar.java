package com.mateus.quizdoprojetofinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.style.QuoteSpan;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.mateus.quizdoprojetofinal.atividade.MainActivity;

public class ComoJogar extends AppCompatActivity {
    private Button btnIniciarJogo2;
    private ImageButton btnVQ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_como_jogar);

        btnIniciarJogo2 = findViewById(R.id.btnIniciarJogo2);
        btnVQ = findViewById(R.id.btnVQ);

        btnIniciarJogo2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirPerum();
            }
        });
        btnVQ.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirMain();
            }
        });
    }
    private void abrirPerum()
    {
        Intent janelap = new Intent(this, QuestaoUm.class);
        startActivity(janelap);
    }
    private void abrirMain()
    {
        Intent janlelam = new Intent(this, MainActivity.class);
        startActivity(janlelam);
    }
}