package com.mateus.quizdoprojetofinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.mateus.quizdoprojetofinal.atividade.MainActivity;

import static com.mateus.quizdoprojetofinal.atividade.MainActivity.acertos;

public class QuestaoDez extends AppCompatActivity {
    private Button btnSete, btnOnze, btnDez, btnCinco;
    private TextView txtCashQ10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questao_dez);

        btnSete = findViewById(R.id.btnSete);
        btnOnze = findViewById(R.id.btnOnze);
        btnDez = findViewById(R.id.btnDez);
        btnCinco = findViewById(R.id.btnCinco);
        txtCashQ10 = findViewById(R.id.txtCashQ10);

        txtCashQ10.setText(" " + MainActivity.acertos);

        btnSete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                acertos = acertos + 1000;
                abrirProx();
            }
        });
        btnOnze.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirProx();
            }
        });
        btnDez.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirProx();
            }
        });
        btnCinco.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirProx();
            }
        });
    }
    private void abrirProx()
    {
        Intent janela = new Intent(this, FinalQuiz.class);
        startActivity(janela);
        finish();
    }
}